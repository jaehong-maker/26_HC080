# DynamoDB와의 통신(상태, 로그, 설정 읽기/쓰기)을 전담하는 유틸리티 파일임


# DynamoDB 등 데이터베이스와의 통신 및 쿼리를 담당하는 유틸리티 모듈


import boto3
import random
import logging
import math
from decimal import Decimal
from boto3.dynamodb.conditions import Attr, Key
import uuid
from datetime import datetime, timezone, timedelta
import config

logger = logging.getLogger()

dynamodb = boto3.resource("dynamodb")
log_table = dynamodb.Table("DiffuserLog")
state_table = dynamodb.Table("DiffuserState")
pref_table = dynamodb.Table("DiffuserPref")
user_table = dynamodb.Table("DiffuserUsers")
auth_table = dynamodb.Table("DiffuserAuth")
ambient_table = dynamodb.Table("AmbientWeights")
diary_table = dynamodb.Table("UserDiaries")


def _get_kst_now():
    return datetime.now(timezone(timedelta(hours=9)))


# 사용자 감정 일기를 DB에 저장함
def save_diary(email, diary_text, emotion, scent_text):
    """
    사용자의 일기와 감정 분석 결과를 UserDiaries 테이블에 저장함.
    """
    try:
        now = _get_kst_now()
        item = {
            'email': email,
            'timestamp': now.isoformat(),
            'diary_id': str(uuid.uuid4()),
            'text': diary_text,
            'emotion': emotion,
            'scent': scent_text,
            'date': now.strftime("%Y-%m-%d")
        }
        diary_table.put_item(Item=item)
        return True
    except Exception as e:
        logger.error(f"Save Diary Error: {e}")
        return False


# 사용자의 이전 일기 목록을 조회함
def get_user_diaries(email, limit=20):
    """
    사용자의 일기 목록을 최신순으로 가져옵니다.
    """
    try:
        res = diary_table.query(
            KeyConditionExpression=Key('email').eq(email),
            ScanIndexForward=False,  # 최신순
            Limit=limit
        )
        return res.get('Items', [])
    except Exception as e:
        logger.error(f"Get Diaries Error: {e}")
        return []


def _kind_ids():
    return [int(kind_id) for kind_id in getattr(config, "KIND_IDS", (1, 2, 3, 4, 5, 6))]


def _default_spray_to_kind():
    default_mapping = getattr(config, "DEFAULT_SPRAY_TO_KIND", None)
    if isinstance(default_mapping, dict):
        try:
            return {int(spray): int(kind) for spray, kind in default_mapping.items()}
        except Exception:
            pass
    return {1: 1, 2: 2, 3: 3, 4: 4}


def _parse_int(value, default=0):
    try:
        return int(float(value))
    except Exception:
        return default


def _normalize_kind_slots(raw_slots):
    if isinstance(raw_slots, list):
        source_values = raw_slots[:4]
    elif isinstance(raw_slots, str) and raw_slots.strip():
        source_values = raw_slots.replace(",", "_").split("_")[:4]
    elif raw_slots not in (None, ""):
        source_values = [raw_slots]
    else:
        source_values = []

    valid_kinds = set(_kind_ids())
    slots = []
    for value in source_values:
        kind = _parse_int(value, 0)
        slots.append(kind if kind in valid_kinds else 0)

    while len(slots) < 4:
        slots.append(0)

    return slots[:4]


def _mapping_to_kind_slots(mapping):
    return [_parse_int(mapping.get(spray_no), 0) for spray_no in range(1, 5)]


def _parse_spray_mapping(mapping_value):
    if isinstance(mapping_value, dict):
        return {int(k): int(v) for k, v in mapping_value.items() if 1 <= int(k) <= 4}

    if isinstance(mapping_value, list):
        return {idx + 1: int(kind) for idx, kind in enumerate(_normalize_kind_slots(mapping_value))}

    if isinstance(mapping_value, str) and mapping_value.strip():
        mapping = {}
        for pair in mapping_value.split(","):
            if ":" in pair:
                spray, kind = pair.split(":", 1)
                spray_no = _parse_int(spray, 0)
                kind_no = _parse_int(kind, 0)
                if 1 <= spray_no <= 4:
                    mapping[spray_no] = kind_no
        if mapping:
            return mapping

        slots = _normalize_kind_slots(mapping_value)
        return {idx + 1: kind for idx, kind in enumerate(slots)}

    return {}


def _ambient_scent_ids():
    return [int(scent_id) for scent_id in getattr(config, "AMBIENT_SCENT_IDS", _kind_ids())]


def _ambient_device_scent_ids():
    configured = getattr(config, "AMBIENT_DEVICE_SCENT_IDS", None)
    if configured is not None:
        return [int(scent_id) for scent_id in configured]
    return _ambient_scent_ids()


def _build_ambient_seed_update():
    assignments = [
        f"scent_{scent_id}_score = if_not_exists(scent_{scent_id}_score, :def_weight)"
        for scent_id in _ambient_scent_ids()
    ]
    return "SET " + ", ".join(assignments)


def _read_ambient_scores(item):
    scores = {}
    for scent_id in _ambient_scent_ids():
        scores[scent_id] = int(item.get(f"scent_{scent_id}_score", 50))
    return scores


# list_ambient_context_keys 처리를 담당함
def list_ambient_context_keys():
    context_keys = []
    for time_slot in getattr(config, "AMBIENT_TIME_SLOTS", ()):
        for noise_bucket in getattr(config, "AMBIENT_NOISE_BUCKETS", ()):
            context_keys.append(f"{time_slot['label']}_{noise_bucket['label']}")
    return context_keys


# ensure_ambient_context 처리를 담당함
def ensure_ambient_context(context_key):
    normalized_key = str(context_key or "").strip()
    if not normalized_key:
        return False

    ambient_table.update_item(
        Key={"context_key": normalized_key},
        UpdateExpression=_build_ambient_seed_update(),
        ExpressionAttributeValues={":def_weight": 50},
    )
    return True


# seed_ambient_defaults 처리를 담당함
def seed_ambient_defaults():
    seeded = 0
    for context_key in list_ambient_context_keys():
        try:
            ensure_ambient_context(context_key)
            seeded += 1
        except Exception as e:
            logger.error(f"Ambient Seed Error ({context_key}): {e}")
    return seeded


def get_ambient_spray_recommendation(noise_bucket, device_id, weights=None):
    """Return a ranked scent and its usable physical slot, excluding low fluid."""
    try:
        ambient_ids = set(_ambient_scent_ids())
        ambient_ids.discard(7)

        configured = getattr(config, "AMBIENT_SCENTS_BY_BUCKET", {})
        priority = [
            int(kind)
            for kind in configured.get(str(noise_bucket), ())
            if int(kind) in ambient_ids
        ]
        fallback_order = [
            int(kind)
            for kind in getattr(config, "AMBIENT_SCENT_FALLBACK_ORDER", ())
            if int(kind) in ambient_ids and int(kind) not in priority
        ]

        mapping = get_spray_mapping(device_id)
        usable_slots = {}
        minimum = float(getattr(config, "AMBIENT_MIN_SCENT_PERCENT", 15))
        for raw_slot, raw_kind in mapping.items():
            try:
                slot, kind = int(raw_slot), int(raw_kind)
                if slot not in (1, 2, 3, 4) or kind not in ambient_ids:
                    continue
                if weights is not None:
                    if not isinstance(weights, list) or slot > len(weights):
                        continue
                    percent = float(weights[slot - 1])
                    if not math.isfinite(percent) or percent < minimum:
                        continue
                usable_slots.setdefault(kind, []).append(slot)
            except (TypeError, ValueError, OverflowError):
                continue
        for kind in priority + fallback_order:
            if kind in usable_slots:
                return kind, min(usable_slots[kind]), priority

        logger.warning(
            f"[AMBIENT_SCENT_UNAVAILABLE] ID:{device_id} "
            f"Bucket:{noise_bucket} UsableKinds:{sorted(usable_slots)} Weights:{weights}"
        )
        return 0, 0, priority
    except Exception as e:
        logger.error(f"Ambient Fixed Scent Recommendation Error: {e}")
        return 0, 0, []


def get_ambient_scent_recommendation(noise_bucket, device_id):
    """Compatibility wrapper for callers that only need the installed kind."""
    kind, _, priority = get_ambient_spray_recommendation(noise_bucket, device_id)
    return kind, priority


# 룰렛 알고리즘으로 앰비언트 모드 향기를 추천함
def get_ambient_recommendation(context_key, device_id):
    """
    get_ambient_recommendation 함수: 1-9-90 룰렛 알고리즘 (Softmax/Ratio) 적용
    """
    try:
        ensure_ambient_context(context_key)
        resp = ambient_table.get_item(Key={"context_key": str(context_key)})
        item = resp.get("Item") or {}

        scores = _read_ambient_scores(item)
        
        installed_kinds = set(_active_kinds(device_id))
        if not installed_kinds:
            installed_kinds = set(_default_spray_to_kind().values())

        # 장착된 향기만 필터링하여 최소 가중치 1 보장
        valid_scores = {k: max(1, scores.get(k, 50)) for k in installed_kinds}
        kinds = list(valid_scores.keys())
        weights = list(valid_scores.values())
        
        if not kinds:
            return int(getattr(config, "AMBIENT_DEFAULT_SCENT", 1)), scores
            
        # 룰렛(비율 배분) 돌리기
        best_kind = random.choices(kinds, weights=weights, k=1)[0]

        return best_kind, scores
    except Exception as e:
        logger.error(f"Ambient Recommendation Error: {e}")
        return int(getattr(config, "AMBIENT_DEFAULT_SCENT", 1)), {
            kind_id: 50 for kind_id in _ambient_scent_ids()
        }


def get_ambient_alternative(context_key, device_id, excluded_kind):
    try:
        ensure_ambient_context(context_key)
        resp = ambient_table.get_item(Key={"context_key": str(context_key)})
        item = resp.get("Item") or {}
        scores = _read_ambient_scores(item)
        installed_kinds = set(_active_kinds(device_id))
        candidates = [
            kind for kind in installed_kinds
            if kind in _ambient_scent_ids() and int(kind) != int(excluded_kind)
        ]
        if not candidates:
            candidates = [
                kind for kind in _ambient_scent_ids()
                if int(kind) != int(excluded_kind)
            ]
        weights = [max(1, scores.get(kind, 50)) for kind in candidates]
        return random.choices(candidates, weights=weights, k=1)[0]
    except Exception as e:
        logger.error(f"Ambient Alternative Error: {e}")
        fallback = [kind for kind in _ambient_scent_ids() if int(kind) != int(excluded_kind)]
        return fallback[0] if fallback else int(getattr(config, "AMBIENT_DEFAULT_SCENT", 1))


# 앰비언트 모드 피드백을 가중치에 반영함
def save_ambient_feedback(context_key, scent_code, weight_change):
    """
    save_ambient_feedback 함수: 앱의 좋아요/별로예요 피드백 반영, 하한선 1 유지
    """
    try:
        normalized_key = str(context_key or "").strip()
        scent_no = int(scent_code)
        if scent_no not in _ambient_scent_ids():
            return False

        ensure_ambient_context(normalized_key)
        
        resp = ambient_table.get_item(Key={"context_key": normalized_key})
        item = resp.get("Item") or {}
        
        score_col = f"scent_{scent_no}_score"
        current_score = int(item.get(score_col, 50))
        
        new_score = current_score + int(weight_change)
        new_score = max(1, min(100, new_score))
        
        ambient_table.update_item(
            Key={"context_key": normalized_key},
            UpdateExpression=f"SET {score_col} = :val",
            ExpressionAttributeValues={":val": new_score},
        )
        return True
    except Exception as e:
        logger.error(f"Ambient Feedback Save Error: {e}")
        return False


# get_spray_mapping 처리를 담당함
def get_spray_mapping(device_id, email=None):
    """Return {spray_no: kind_no}. Supports both spray_mapping and kind_slots."""
    try:
        if email:
            try:
                user_res = user_table.get_item(Key={"email": email})
                user_item = user_res.get("Item") or {}
                if user_item.get("spray_mapping"):
                    mapping = _parse_spray_mapping(user_item.get("spray_mapping"))
                    if mapping:
                        return {**_default_spray_to_kind(), **mapping}
            except Exception as e:
                logger.error(f"User Table Mapping Load Error: {e}")

        res = state_table.get_item(Key={"deviceId": device_id})
        item = res.get("Item") or {}

        if item.get("spray_mapping") is not None:
            mapping = _parse_spray_mapping(item.get("spray_mapping"))
            if mapping:
                return {**_default_spray_to_kind(), **mapping}

        if item.get("kind_slots") is not None:
            slots = _normalize_kind_slots(item.get("kind_slots"))
            return {idx + 1: kind for idx, kind in enumerate(slots)}

        if item.get("scent_slots") is not None:
            slots = _normalize_kind_slots(item.get("scent_slots"))
            return {idx + 1: kind for idx, kind in enumerate(slots)}
    except Exception as e:
        logger.error(f"Spray Mapping Load Error: {e}")

    return _default_spray_to_kind()


# get_kind_slots 처리를 담당함
def get_kind_slots(device_id):
    return _mapping_to_kind_slots(get_spray_mapping(device_id))


# save_spray_mapping 처리를 담당함
def save_spray_mapping(device_id, mapping, email=None):
    try:
        parsed_mapping = _parse_spray_mapping(mapping)
        if not parsed_mapping:
            parsed_mapping = _default_spray_to_kind()

        normalized_mapping = {spray: parsed_mapping.get(spray, 0) for spray in range(1, 5)}
        kind_slots = _mapping_to_kind_slots(normalized_mapping)
        mapping_str = ",".join(f"{spray}:{kind}" for spray, kind in normalized_mapping.items())

        state_table.update_item(
            Key={"deviceId": device_id},
            UpdateExpression="set spray_mapping = :m, kind_slots = :ks",
            ExpressionAttributeValues={":m": mapping_str, ":ks": kind_slots},
        )
        
        if email:
            try:
                user_table.update_item(
                    Key={"email": email},
                    UpdateExpression="set spray_mapping = :m",
                    ExpressionAttributeValues={":m": mapping_str},
                )
            except Exception as e:
                logger.error(f"User Table Mapping Save Error: {e}")

        return normalized_mapping
    except Exception as e:
        logger.error(f"Spray Mapping Save Error: {e}")
        return None


# get_spray_from_kind 처리를 담당함
def get_spray_from_kind(device_id, kind_code):
    try:
        target_kinds = [int(k) for k in str(kind_code) if k.isdigit()]
        
        mapping = get_spray_mapping(device_id)
        kind_to_spray = {int(k): int(s) for s, k in mapping.items()}
        
        valid_sprays = []
        for tk in target_kinds:
            if tk in kind_to_spray:
                valid_sprays.append(str(kind_to_spray[tk]))
        
        if valid_sprays:
            unique_sprays = sorted(list(set(valid_sprays)))
            return int("".join(unique_sprays))
            
    except Exception as e:
        logger.error(f"Kind To Spray Error: {e}")
    return None

_SCENT_SIMILARITY = {
    1: [4, 5, 2, 6, 3], # 시트러스 -> 페퍼민트, 라벤더, 센달우드...
    2: [3, 5, 6, 4, 1], # 센달우드 -> 패츄리, 라벤더, 바닐라...
    3: [2, 5, 4, 1, 6], # 패츄리 -> 센달우드, 라벤더, 페퍼민트...
    4: [1, 5, 2, 3, 6], # 페퍼민트 -> 시트러스, 라벤더, 센달우드...
    5: [6, 2, 3, 4, 1], # 라벤더 -> 바닐라, 센달우드, 패츄리...
    6: [5, 2, 1, 4, 3], # 바닐라 -> 라벤더, 센달우드, 시트러스...
    7: [1, 5, 4, 2, 6, 3] # 물 -> 가벼운 향부터
}

# 기기에 장착된 향기 중 가장 적절한 향기를 매핑해줌
def get_smart_spray_mapping(device_id, kind_code):
    try:
        target_kinds = [int(k) for k in str(kind_code) if k.isdigit()]
        if not target_kinds:
            return 1, " (알림: 향기 인식 오류로 기본 1번 향기로 대체됩니다.)"
            
        mapping = get_spray_mapping(device_id)
        kind_to_spray = {int(k): int(s) for s, k in mapping.items()}
        
        valid_sprays = []
        found_kinds = []
        for tk in target_kinds:
            if tk in kind_to_spray:
                valid_sprays.append(str(kind_to_spray[tk]))
                found_kinds.append(tk)
                
        if valid_sprays:
            unique_sprays = sorted(list(set(valid_sprays)))
            mapped_code = int("".join(unique_sprays))
            
            if len(found_kinds) < len(target_kinds):
                missing = set(target_kinds) - set(found_kinds)
                return mapped_code, f" (알림: {','.join(map(str, missing))}번 향기가 미장착되어 장착된 {','.join(map(str, found_kinds))}번 향기만 분사합니다.)"
            return mapped_code, ""
            
        primary_target = target_kinds[0]
        installed_kinds = list(kind_to_spray.keys())
        
        if not installed_kinds:
            return 1, " (알림: 기기에 장착된 향기 정보가 없어 기본 1번 펌프가 분사됩니다.)"
            
        similar_list = _SCENT_SIMILARITY.get(primary_target, [1, 2, 3, 4, 5, 6, 7])
        
        fallback_kind = None
        for sim_kind in similar_list:
            if sim_kind in installed_kinds:
                fallback_kind = sim_kind
                break
                
        if fallback_kind is None:
            fallback_kind = installed_kinds[0]
            
        mapped_pump = kind_to_spray[fallback_kind]
        return mapped_pump, f" (알림: 추천 향기가 기기에 없어 가장 유사한 {fallback_kind}번 향기로 대체 분사합니다.)"
        
    except Exception as e:
        logger.error(f"Smart Mapping Error: {e}")
        return 1, " (알림: 매핑 에러로 기본 1번 향기로 대체됩니다.)"


# get_kind_from_spray 처리를 담당함
def get_kind_from_spray(device_id, spray_no):
    try:
        return get_spray_mapping(device_id).get(int(spray_no))
    except Exception as e:
        logger.error(f"Spray To Kind Error: {e}")
        return None


def _active_kinds(device_id):
    mapping = get_spray_mapping(device_id)
    valid_kinds = set(_kind_ids())
    return [int(kind) for kind in mapping.values() if int(kind) in valid_kinds]


# get_music_track 처리를 담당함
def get_music_track(device_id, spray_or_kind_code, is_pump=False):
    """Return a music track for the resolved spray slot.

    The argument may be a spray number, a kind number, or a blend-like code.
    If a kind is loaded in a spray slot, that slot's saved music is used.
    """
    original_code = spray_or_kind_code
    try:
        code_str = str(spray_or_kind_code)
        if not is_pump and len(code_str) >= 2 and 1 <= int(code_str) <= 89:
            candidates = [int(digit) for digit in code_str if int(digit) in _kind_ids()]
            spray_or_kind_code = random.choice(candidates) if candidates else int(code_str[0])

        code = int(spray_or_kind_code)
        if is_pump:
            spray_no = int(str(code)[0])
        else:
            spray_no = get_spray_from_kind(device_id, code)
            if spray_no is None and 1 <= code <= 4:
                spray_no = code

        res = state_table.get_item(Key={"deviceId": device_id})
        if "Item" in res and "music_tracks" in res["Item"]:
            track_list = str(res["Item"]["music_tracks"]).split("_")
            if spray_no is not None and 1 <= int(spray_no) <= 4 and len(track_list) == 4:
                raw_track = track_list[int(spray_no) - 1]
                first_track = raw_track.split(",")[0].strip()
                return int(first_track)
    except Exception as e:
        logger.error(f"Music Load Error: {e}")

    defaults = {1: 1, 2: 6, 3: 11, 4: 16}
    try:
        code = int(str(original_code)[0])
        if is_pump:
            spray_no = code
        else:
            spray_no = get_spray_from_kind(device_id, code)
        target = int(spray_no) if spray_no is not None else code
        return defaults.get(target, target)
    except Exception:
        return 0


def _get_email_by_device_id(device_id):
    try:
        resp = user_table.scan(
            FilterExpression=Attr("deviceId").eq(str(device_id)),
            ProjectionExpression="email",
            Limit=1,
        )
        items = resp.get("Items") or []
        if items:
            return str(items[0].get("email", "")).strip()
    except Exception as e:
        logger.error(f"User Email Load Error: {e}")
    return None


# save_feedback 처리를 담당함
def save_feedback(device_id, context, kind_code, weight_change, email=None):
    try:
        kind_no = int(kind_code)
        if kind_no not in _kind_ids():
            return False

        score_col = f"scent_{kind_no}_score"
        
        target_email = email or _get_email_by_device_id(device_id)
        if not target_email:
            logger.error("Feedback Save Error: email not found")
            return False
            
        pref_table.update_item(
            Key={"email": str(target_email), "context": str(context)},
            UpdateExpression=f"ADD {score_col} :val",
            ExpressionAttributeValues={":val": int(weight_change)},
        )
        return True
    except Exception as e:
        print(f"[DEBUG] 저장 실패 원인: {str(e)}")
        logger.error(f"Feedback Save Error: {e}")
        return False


_IMPLICIT_LIKE_FIELDS = (
    "pending_implicit_context",
    "pending_implicit_kind",
    "pending_implicit_email",
    "pending_implicit_due",
    "pending_implicit_token",
    "pending_implicit_store",
)


def cancel_implicit_like(device_id):
    try:
        state_table.update_item(
            Key={"deviceId": device_id},
            UpdateExpression="REMOVE " + ", ".join(_IMPLICIT_LIKE_FIELDS),
        )
        return True
    except Exception as e:
        logger.error(f"Implicit Like Cancel Error: {e}")
        return False


def schedule_implicit_like(
    device_id,
    context,
    kind_code,
    email=None,
    delay_seconds=600,
    feedback_store="preference",
):
    try:
        kind_no = int(kind_code)
        if kind_no not in _kind_ids() or not str(context or "").strip():
            return False

        normalized_store = str(feedback_store or "preference").strip().lower()
        if normalized_store not in ("preference", "ambient"):
            return False

        target_email = email or _get_email_by_device_id(device_id) or ""
        due_epoch = int(_get_kst_now().timestamp()) + max(0, int(delay_seconds))
        token = uuid.uuid4().hex
        state_table.update_item(
            Key={"deviceId": device_id},
            UpdateExpression=(
                "SET pending_implicit_context = :ctx, pending_implicit_kind = :kind, "
                "pending_implicit_email = :email, pending_implicit_due = :due, "
                "pending_implicit_token = :token, pending_implicit_store = :store"
            ),
            ExpressionAttributeValues={
                ":ctx": str(context),
                ":kind": kind_no,
                ":email": str(target_email),
                ":due": due_epoch,
                ":token": token,
                ":store": normalized_store,
            },
        )
        logger.info(
            f"[IMPLICIT_LIKE_SCHEDULED] ID:{device_id} Context:{context} "
            f"Kind:{kind_no} Due:{due_epoch}"
        )
        return True
    except Exception as e:
        logger.error(f"Implicit Like Schedule Error: {e}")
        return False


def apply_due_implicit_like(device_id, now_epoch=None):
    try:
        response = state_table.get_item(Key={"deviceId": device_id}, ConsistentRead=True)
        item = response.get("Item") or {}
        due_epoch = _parse_int(item.get("pending_implicit_due"), 0)
        current_epoch = int(now_epoch) if now_epoch is not None else int(_get_kst_now().timestamp())
        if due_epoch <= 0 or current_epoch < due_epoch:
            return None

        context = str(item.get("pending_implicit_context") or "").strip()
        kind_no = _parse_int(item.get("pending_implicit_kind"), 0)
        email = str(item.get("pending_implicit_email") or "").strip() or None
        token = str(item.get("pending_implicit_token") or "").strip()
        feedback_store = str(item.get("pending_implicit_store") or "preference").strip().lower()
        if not context or kind_no not in _kind_ids() or not token:
            cancel_implicit_like(device_id)
            return None

        try:
            state_table.update_item(
                Key={"deviceId": device_id},
                UpdateExpression="REMOVE " + ", ".join(_IMPLICIT_LIKE_FIELDS),
                ConditionExpression=(
                    "pending_implicit_token = :token AND pending_implicit_due = :due"
                ),
                ExpressionAttributeValues={":token": token, ":due": due_epoch},
            )
        except Exception as e:
            error_code = getattr(e, "response", {}).get("Error", {}).get("Code", "")
            if error_code == "ConditionalCheckFailedException":
                return None
            raise

        if feedback_store == "ambient":
            saved = save_ambient_feedback(context, kind_no, 1)
        else:
            saved = save_feedback(device_id, context, kind_no, 1, email)

        if not saved:
            logger.error(
                f"[IMPLICIT_LIKE_SAVE_FAILED] ID:{device_id} Context:{context} Kind:{kind_no}"
            )
            return None

        result = {"context": context, "kind": kind_no, "value": 1, "store": feedback_store}
        logger.info(f"[IMPLICIT_LIKE_APPLIED] ID:{device_id} {result}")
        return result
    except Exception as e:
        logger.error(f"Implicit Like Apply Error: {e}")
        return None


# get_personalized_scent 처리를 담당함
def get_personalized_scent(device_id, context, default_kind, email=None):
    try:
        target_email = email or _get_email_by_device_id(device_id)
        if not target_email:
            return default_kind, "기본 추천(이메일 없음)"

        resp = pref_table.get_item(Key={"email": str(target_email), "context": str(context)})
        item = resp.get("Item")
        if not item:
            return default_kind, "기본 추천"

        scores = {kind: int(item.get(f"scent_{kind}_score", 0)) for kind in _kind_ids()}
        active_kinds = _active_kinds(device_id)
        candidate_scores = {kind: scores.get(kind, 0) for kind in active_kinds}

        if not candidate_scores:
            return default_kind, "기본 추천"

        if not any(score != 0 for score in candidate_scores.values()):
            return default_kind, "기본 추천"

        max_score = max(candidate_scores.values())
        best_kinds = [kind for kind, score in candidate_scores.items() if score == max_score]
        if int(default_kind) in best_kinds:
            return default_kind, "가중치 확인(유지)"
        return random.choice(best_kinds), "사용자 선호 가중치 적용"

    except Exception as e:
        logger.error(f"Personalization Error: {e}")
        return default_kind, "에러(기본값)"


def get_preferred_alternative(device_id, context, excluded_kind, email=None):
    """현재 향을 제외하고 해당 context에서 점수가 가장 높은 장착 향을 고름."""
    try:
        excluded_no = int(excluded_kind)
        candidates = [kind for kind in _active_kinds(device_id) if int(kind) != excluded_no]
        if not candidates:
            candidates = [kind for kind in _kind_ids() if int(kind) != excluded_no]
        if not candidates:
            return None

        target_email = email or _get_email_by_device_id(device_id)
        if not target_email:
            return random.choice(candidates)

        response = pref_table.get_item(
            Key={"email": str(target_email), "context": str(context)}
        )
        item = response.get("Item") or {}
        scores = {
            kind: int(item.get(f"scent_{kind}_score", 0))
            for kind in candidates
        }
        max_score = max(scores.values())
        best_kinds = [kind for kind, score in scores.items() if score == max_score]
        return random.choice(best_kinds)
    except Exception as e:
        logger.error(f"Preferred Alternative Error: {e}")
        return None


# get_user_history_text 처리를 담당함
def get_user_history_text(device_id, email=None, contexts=None):
    try:
        target_email = email or _get_email_by_device_id(device_id)
        if not target_email:
            return "사용자 취향 데이터 없음"

        allowed_contexts = None
        if contexts:
            allowed_contexts = {str(context) for context in contexts}
            
        resp = pref_table.query(
            KeyConditionExpression=Key('email').eq(str(target_email))
        )
        items = resp.get("Items", [])
        if not items:
            return "사용자 취향 데이터 없음"
            
        history_lines = []
        for item in items:
            context = item.get("context", "")
            if allowed_contexts is not None and context not in allowed_contexts:
                continue
            scores = []
            for kind in _kind_ids():
                score = int(item.get(f"scent_{kind}_score", 0))
                if score > 0:
                    scores.append(f"{kind}번 향기 +{score}")
                elif score < 0:
                    scores.append(f"{kind}번 향기 {score}")
            if scores:
                history_lines.append(f"[{context} 상황]: " + ", ".join(scores))
                
        if not history_lines:
            return "특별한 선호도 기록 없음"
        return "\n".join(history_lines)
    except Exception as e:
        logger.error(f"User History Error: {e}")
        return "사용자 데이터 로딩 에러"


# 기기가 수행할 다음 명령(메일박스)을 저장하거나 읽어옴
def manage_mailbox(
    device_id,
    save_cmd=None,
    save_region=None,
    save_duration=None,
    is_peek=False,
    save_active_mode=None,
    save_active_scent=None,
    save_led=None,
    save_music=None,
    save_ambient_window_start=None,
    expected_initial_state=None,
    save_ambient_probe_start=None,
    save_ambient_lease_duration=None,
    save_ambient_metadata=None,
):
    try:
        if save_cmd is not None:
            update_exp = "set pending_cmd = :c, current_spray = :c"
            exp_vals = {":c": int(save_cmd)}

            if save_region:
                update_exp += ", pending_region = :r, last_region = :r"
                exp_vals[":r"] = str(save_region)

            if save_duration is not None:
                update_exp += ", pending_duration = :d"
                exp_vals[":d"] = int(save_duration)

            if save_active_mode is not None:
                update_exp += ", active_mode = :am"
                exp_vals[":am"] = str(save_active_mode)

            if save_active_scent is not None:
                update_exp += ", active_scent = :as"
                exp_vals[":as"] = int(save_active_scent)

            if save_led is not None:
                update_exp += ", led_r = :lr, led_g = :lg, led_b = :lb, led_br = :lbr"
                exp_vals[":lr"] = int(save_led["led_r"])
                exp_vals[":lg"] = int(save_led["led_g"])
                exp_vals[":lb"] = int(save_led["led_b"])
                exp_vals[":lbr"] = int(save_led["led_bright"])

            if save_music is not None:
                update_exp += ", current_music = :music"
                exp_vals[":music"] = int(save_music)

            remove_fields = []
            if save_ambient_lease_duration is None:
                # An explicit stop or a command from another mode supersedes
                # any older continuous-ambient authorization.
                update_exp += ", ambient_renewal_enabled = :renewal_off"
                exp_vals[":renewal_off"] = False
                remove_fields.extend(["ambient_lease_expires_at", "ambient_renew_at", "ambient_lease_token"])

            if save_ambient_probe_start is not None:
                update_exp += (
                    ", ambient_startup_pending = :probe_pending, "
                    "ambient_startup_awaiting_poll = :probe_pending, "
                    "ambient_startup_started_at = :probe_start, "
                    "ambient_startup_samples = :probe_samples, "
                    "ambient_startup_token = :probe_token, ambient_context = :probe_context, "
                    "db_samples = :probe_samples, "
                    "db_window_started_at = :probe_start, db_window_ready = :probe_false"
                )
                exp_vals.update({
                    ":probe_pending": True, ":probe_start": int(save_ambient_probe_start),
                    ":probe_samples": [], ":probe_token": uuid.uuid4().hex,
                    ":probe_context": "", ":probe_false": False,
                })
                remove_fields.extend(["auto_stop_time", "ambient_initial_started_at", "ambient_music_changed_at"])

            if save_ambient_window_start is not None:
                # Start a fresh measurement session with the initial command.
                # Its first hardware POLL establishes the first sample time.
                # Keep the actual last-valid timestamp across window resets.
                update_exp += (
                    ", ambient_initial_started_at = :aws, db_window_started_at = :aws, "
                    "db_samples = :empty_samples, "
                    "db_window_ready = :not_ready, ambient_loud_since = :zero, "
                    "ambient_sustained_loud = :not_ready, ambient_startup_pending = :not_ready"
                )
                exp_vals[":aws"] = int(save_ambient_window_start)
                exp_vals[":empty_samples"] = []
                exp_vals[":zero"] = 0
                exp_vals[":not_ready"] = False
                remove_fields.append("auto_stop_time")

            if save_ambient_lease_duration is not None:
                lease_duration = int(save_ambient_lease_duration)
                margin = int(config.AMBIENT_RENEWAL_MARGIN_SECONDS)
                if not 0 < margin < lease_duration <= 270 or int(save_cmd) <= 0:
                    raise ValueError("Invalid ambient lease duration/margin")
                update_exp += (
                    ", ambient_lease_duration = :lease_duration, "
                    "ambient_lease_token = :lease_token, ambient_renewal_enabled = :renewal_on"
                )
                exp_vals.update({":lease_duration": lease_duration, ":lease_token": uuid.uuid4().hex, ":renewal_on": True})
                remove_fields.extend(["ambient_lease_expires_at", "ambient_renew_at"])

            if save_ambient_metadata:
                allowed_fields = {
                    "ambient_context", "ambient_effective_db", "ambient_last_eval_time", "ambient_music_changed_at",
                    "db_avg", "db_stddev", "noise_type", "is_spike",
                }
                for index, (field, value) in enumerate(save_ambient_metadata.items()):
                    if field not in allowed_fields:
                        raise ValueError("Unexpected ambient metadata field: " + field)
                    token = ":ambient_meta_" + str(index)
                    update_exp += ", " + field + " = " + token
                    exp_vals[token] = value

            if remove_fields:
                update_exp += " REMOVE " + ", ".join(dict.fromkeys(remove_fields))

            write_options = {}
            if expected_initial_state is not None:
                # Claim the initial run once, and reject a start superseded by
                # a stop/mode change while its recommendation was in flight.
                conditions = []
                for field in (
                    "active_mode", "last_mode_change_time", "ambient_startup_token",
                    "ambient_startup_pending", "ambient_lease_token", "ambient_renewal_enabled", "pending_cmd",
                ):
                    if field in expected_initial_state:
                        token = ":expected_" + field
                        conditions.append(field + " = " + token)
                        exp_vals[token] = expected_initial_state[field]
                    else:
                        conditions.append("attribute_not_exists(" + field + ")")
                write_options["ConditionExpression"] = " AND ".join(conditions)

            state_table.update_item(
                Key={"deviceId": device_id},
                UpdateExpression=update_exp,
                ExpressionAttributeValues=exp_vals,
                **write_options,
            )
            logger.info(f"[Mailbox_Write] ID:{device_id} Cmd:{save_cmd}")
            return int(save_cmd)

        res = state_table.get_item(Key={"deviceId": device_id}, ConsistentRead=True)
        if "Item" in res:
            item = res["Item"]
            cmd = int(item.get("pending_cmd", -1))
            saved_region = item.get("pending_region", "") or item.get("last_region", "")
            saved_duration = int(item.get("pending_duration", 3))

            current_spray = int(item.get("current_spray", -1))

            if cmd != -1:
                if not is_peek:
                    read_update = "set pending_cmd = :z, pending_region = :e, pending_duration = :d"
                    read_values = {":z": -1, ":e": "", ":d": 3, ":expected_cmd": cmd}
                    read_condition = "pending_cmd = :expected_cmd"
                    if (
                        cmd > 0 and item.get("active_mode") == "ambient"
                        and item.get("ambient_renewal_enabled", False)
                        and item.get("ambient_lease_token")
                    ):
                        # Time the authorization from delivery, not queueing or
                        # an app's peek. The device starts its timer on receipt.
                        delivered_at = int(_get_kst_now().timestamp())
                        margin = int(config.AMBIENT_RENEWAL_MARGIN_SECONDS)
                        read_update += ", ambient_lease_expires_at = :expires, ambient_renew_at = :renew"
                        read_values.update({
                            ":expires": delivered_at + saved_duration,
                            ":renew": delivered_at + saved_duration - margin,
                            ":expected_lease": item["ambient_lease_token"],
                        })
                        read_condition += " AND ambient_lease_token = :expected_lease"
                    state_table.update_item(
                        Key={"deviceId": device_id},
                        UpdateExpression=read_update,
                        ExpressionAttributeValues=read_values,
                        ConditionExpression=read_condition,
                    )
                    logger.info(f"[Mailbox_Read] ID:{device_id} Executing Cmd:{cmd}")
                else:
                    logger.info(f"[Mailbox_Peek] ID:{device_id} Peeked Cmd:{cmd}")

                return cmd, saved_region, saved_duration

            if is_peek and current_spray > 0:
                return current_spray, saved_region, saved_duration

            if saved_region:
                return -1, saved_region, saved_duration

        return -1, get_saved_region(device_id), 3
    except Exception as e:
        logger.error(f"Mailbox Error: {e}")
        if expected_initial_state is not None:
            return None
        return -1, get_saved_region(device_id), 3


def renew_ambient_lease(device_id, now_epoch=None):
    """Queue a finite extension only when due, using the active session's scent."""
    state = state_table.get_item(Key={"deviceId": device_id}, ConsistentRead=True).get("Item", {})
    now_epoch = int(_get_kst_now().timestamp()) if now_epoch is None else int(now_epoch)
    due = int(state.get("ambient_renew_at", 0) or 0)
    scent = int(state.get("active_scent", 0) or 0)
    if (
        state.get("active_mode") != "ambient" or state.get("ambient_startup_pending", False)
        or not state.get("ambient_renewal_enabled", False) or scent <= 0
        or int(state.get("pending_cmd", -1)) != -1 or due <= 0 or now_epoch < due
    ):
        return False
    duration = int(config.AMBIENT_DURATION_SECONDS)
    saved = manage_mailbox(
        device_id, scent, state.get("ambient_context", ""), duration,
        save_active_mode="ambient", save_active_scent=scent,
        save_ambient_lease_duration=duration, expected_initial_state=state,
    )
    return saved == scent


def select_ambient_music(bucket, suggested_music=0, current_music=0):
    """Keep AI suggestions and deterministic fallbacks inside the bucket."""
    tracks = list(dict.fromkeys(track for track in config.AMBIENT_MUSIC_BY_BUCKET.get(bucket, ())
                                if track in config.AMBIENT_MUSIC_CATALOG))
    if not tracks:
        return 0
    if suggested_music in tracks and suggested_music != current_music:
        return suggested_music
    start = (tracks.index(current_music) + 1) % len(tracks) if current_music in tracks else 0
    return tracks[start]


def rotate_ambient_music(device_id, now_epoch, reported_music=None, music_finished=None):
    """Advance at EOF; retain timed rotation only for older firmware."""
    try:
        state = state_table.get_item(Key={"deviceId": device_id}, ConsistentRead=True).get("Item", {})
        now_epoch = int(now_epoch)
        context = str(state.get("ambient_context", ""))
        bucket = context.rsplit("_", 1)[-1]
        last_change = int(state.get("ambient_music_changed_at", state.get("ambient_last_eval_time", now_epoch)))
        if (
            state.get("active_mode") != "ambient" or state.get("ambient_startup_pending", False)
            or not state.get("ambient_renewal_enabled", False) or int(state.get("active_scent", 0)) <= 0
            or int(state.get("pending_cmd", -1)) == 0
        ):
            return False
        if music_finished is not None:
            # Completion belongs to the reported track, not a timer or a new
            # microphone window. Explicit False means keep playing the song.
            if music_finished is not True or reported_music is None:
                return False
        else:
            # The established ambient context already owns this playlist.
            # Missing microphone samples must not stop legacy music playback.
            if now_epoch - last_change < config.AMBIENT_MUSIC_ROTATION_SECONDS:
                return False
        current = int(state.get("current_music", 0) or 0)
        # A POLL reports the playing track. Wait for delivery of the previous
        # selection instead of replacing a command the device has not applied.
        if current <= 0 or (reported_music is not None and int(reported_music) != current):
            return False
        selected = select_ambient_music(bucket, current_music=current)
        if selected <= 0 or selected == current:
            return False
        values = {":music": selected, ":changed": now_epoch}
        conditions = []
        for field in (
            "active_mode", "last_mode_change_time", "ambient_startup_token", "ambient_startup_pending",
            "ambient_renewal_enabled", "ambient_lease_token", "active_scent", "ambient_context",
            "current_music", "ambient_music_changed_at", "ambient_last_eval_time", "pending_cmd",
        ):
            if field in state:
                token = ":expected_" + field
                values[token] = state[field]
                conditions.append(field + " = " + token)
            else:
                conditions.append("attribute_not_exists(" + field + ")")
        state_table.update_item(
            Key={"deviceId": device_id},
            UpdateExpression="set current_music = :music, ambient_music_changed_at = :changed",
            ExpressionAttributeValues=values, ConditionExpression=" AND ".join(conditions),
        )
        logger.info("[AMBIENT_MUSIC_ROTATE] ID:%s Bucket:%s Track:%s->%s", device_id, bucket, current, selected)
        return True
    except Exception as error:
        logger.warning("Ambient music rotation not saved: %s", error)
        return False


# remember_last_region 처리를 담당함
def remember_last_region(device_id, region):
    try:
        normalized = str(region or "").strip()
        if not normalized:
            return
        state_table.update_item(
            Key={"deviceId": device_id},
            UpdateExpression="set last_region = :r",
            ExpressionAttributeValues={":r": normalized},
        )
    except Exception as e:
        logger.error(f"Remember Region Error: {e}")


# 앱의 사용자 정보에 저장된 지역만 조회함
def get_latest_saved_region(device_id):
    try:
        scan_kwargs = {
            "FilterExpression": Attr("deviceId").eq(str(device_id)),
            "ProjectionExpression": "#r",
            "ExpressionAttributeNames": {"#r": "region"},
            "ConsistentRead": True,
        }
        while True:
            resp = user_table.scan(**scan_kwargs)
            for item in resp.get("Items") or []:
                region = str(item.get("region", "") or "").strip()
                if region in config.REGION_COORDS:
                    logger.info(f"[APP_REGION] Device:{device_id} Region:{region}")
                    return region

            last_evaluated_key = resp.get("LastEvaluatedKey")
            if not last_evaluated_key:
                break
            scan_kwargs["ExclusiveStartKey"] = last_evaluated_key
    except Exception as e:
        logger.error(f"User Region Load Error: {e}")

    return ""


# 앱 저장 지역을 우선하고, 없으면 상태/로그 지역까지 조회하는 범용 함수임
def get_saved_region(device_id):
    app_region = get_latest_saved_region(device_id)
    if app_region:
        return app_region

    try:
        res = state_table.get_item(Key={"deviceId": device_id})
        item = res.get("Item") or {}
        region = str(item.get("last_region", "") or "").strip()
        if region:
            return region
    except Exception as e:
        logger.error(f"State Region Load Error: {e}")

    try:
        resp = log_table.query(
            KeyConditionExpression=Key("deviceId").eq(str(device_id)),
            ScanIndexForward=False,
            Limit=20,
        )
        for item in resp.get("Items") or []:
            region = str(item.get("region", "") or "").strip()
            mode = str(item.get("mode", "") or "").lower()
            if region and region != "Emotion" and ("weather" in mode or region in getattr(config, "REGION_COORDS", {})):
                return region
    except Exception as e:
        logger.error(f"Recent Weather Region Load Error: {e}")

    return ""


# get_latest_voice_region 처리를 담당함
def get_latest_voice_region(device_id="SS"):
    try:
        lookup_device_id = str(device_id or "SS")
        resp = log_table.query(
                KeyConditionExpression=Key("deviceId").eq(lookup_device_id),
                ScanIndexForward=False,
                Limit=30,
        )
        for item in resp.get("Items") or []:
            region = str(item.get("region", "") or "").strip()
            if region and region != "Emotion" and region in getattr(config, "REGION_COORDS", {}):
                logger.info(f"[VoiceRegion] Latest {lookup_device_id} region: {region}")
                return region
    except Exception as e:
        logger.error(f"Voice Region Load Error: {e}")

    return ""


# core_mode_handler 첨부본과 호환되는 최근 응답 지역 조회 함수임
def get_voice_region(device_id="SS"):
    return get_latest_voice_region(device_id)


# get_device_state 처리를 담당함
def get_device_state(device_id):
    try:
        res = state_table.get_item(Key={"deviceId": device_id})
        if "Item" in res:
            return res["Item"]
        return {
            "deviceId": device_id,
            "last_spray_time": "2000-01-01T00:00:00",
            "current_capacity": Decimal(str(config.MAX_CAPACITY)),
            "last_spray_code": 0,
            "weight_g": Decimal("0"),
            "weights": [Decimal("0"), Decimal("0"), Decimal("0"), Decimal("0")],
            "kind_slots": _mapping_to_kind_slots(_default_spray_to_kind()),
        }
    except Exception as e:
        logger.error(f"Device State Load Error: {e}")
        return None


def _normalize_weight_list(weights_value):
    normalized = []

    if isinstance(weights_value, list):
        source_values = weights_value[:4]
    else:
        source_values = [weights_value]

    for value in source_values:
        try:
            normalized.append(float(value))
        except Exception:
            normalized.append(0.0)

    while len(normalized) < 4:
        normalized.append(0.0)

    return normalized[:4]


# update_device_state 처리를 담당함
def update_device_state(device_id, last_time, new_capacity, spray_code, weights_value, weights_raw_value=None):
    try:
        normalized_weights = _normalize_weight_list(weights_value)
        kind_slots = get_kind_slots(device_id)
        kind_code = get_kind_from_spray(device_id, spray_code) or 0

        update_exp = (
            "set last_spray_time = :t, current_capacity = :c, "
            "last_spray_code = :s, last_kind_code = :k, "
            "kind_slots = :ks"
        )
        exp_vals = {
            ":t": last_time,
            ":c": Decimal(str(new_capacity)),
            ":s": int(spray_code),
            ":k": int(kind_code),
            ":ks": kind_slots,
        }

        if weights_raw_value is not None:
            normalized_raw = _normalize_weight_list(weights_raw_value)
            update_exp += ", weights_raw = :wr"
            exp_vals[":wr"] = [Decimal(str(weight)) for weight in normalized_raw]

        state_table.update_item(
            Key={"deviceId": device_id},
            UpdateExpression=update_exp,
            ExpressionAttributeValues=exp_vals,
        )
    except Exception as e:
        logger.error(f"Update Device State Error: {e}")
